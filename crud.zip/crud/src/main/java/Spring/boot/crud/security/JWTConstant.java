package Spring.boot.crud.security;

public class JWTConstant {

    public static String HEADER = "Authorization";
    public static String SECRET_KEY = "jbavlbadlvnogdauysnafuksbjshitsdas";

}